#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_imagebtn_clicked()
{
    QString FileImageName =  QFileDialog:: getOpenFileName(this, tr("Choose"), "", tr("Images (*.png *.jpg*.jpeg*.bmp*.gif)"));

    if (QString::compare(FileImageName, QString()) != 0)
    {
        QImage image;
        bool found = image.load(FileImageName);

        if (found)
        {
            image = image.scaledToWidth(ui->imageLabel->width(), Qt::SmoothTransformation);
            ui->imageLabel->setPixmap(QPixmap::fromImage(image));
        }
        else
        {
            // Somthing didnt work =(
        }
    }
}

void MainWindow::on_pushButton_clicked()
{

}
